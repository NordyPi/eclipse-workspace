package nordlab05;

public class TicTacToeDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TicTacToe game = new TicTacToe();
		game.playGame();
	}

}
