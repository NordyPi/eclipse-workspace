package nordlab14;

public interface MessageEncoder {
	public abstract String encode(String plaintext);
}
