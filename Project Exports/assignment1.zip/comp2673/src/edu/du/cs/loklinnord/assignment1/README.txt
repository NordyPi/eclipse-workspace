Worked with Luke.
We all data parsed and stored in correct structures. Mainly we got stuck trying to produce our string due to hash map null errors. After hours of trouble shooting we both decided to
give up. 