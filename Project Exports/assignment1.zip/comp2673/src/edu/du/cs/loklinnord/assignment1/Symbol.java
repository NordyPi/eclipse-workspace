package edu.du.cs.loklinnord.assignment1;

public interface Symbol {
	// only thing we need is this function to detirmine type
	public boolean isTerminal();
}
