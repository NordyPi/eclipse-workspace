package nordlab12;

public class DayException extends Exception {

	public DayException() {
		System.out.println("DayException");
	}

}
