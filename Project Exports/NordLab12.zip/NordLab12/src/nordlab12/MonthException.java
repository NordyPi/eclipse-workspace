package nordlab12;

public class MonthException extends Exception {

	public MonthException() {
		System.out.println("MonthException");
	}

}
