package nordlab12;

public class ExceptionTest {

	public static void main(String[] args) {
		Object o = new Object();
		String s = (String) o;
	}

}
