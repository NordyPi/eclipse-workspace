package nordlab16;

import edu.du.dudraw.Draw;

public class WanderGameDriver {
	public static void main(String[] args) {
		
		WanderGame game = new WanderGame();
		
	}
}
