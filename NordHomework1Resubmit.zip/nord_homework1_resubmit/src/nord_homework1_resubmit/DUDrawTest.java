package nord_homework1_resubmit;

import edu.du.dudraw.DUDraw;

public class DUDrawTest {

	public static void main(String[] args) {
		DUDraw.setPenColor(255, 0, 255);
		DUDraw.filledCircle(0.25, 0.25, 0.3);

	}

}
